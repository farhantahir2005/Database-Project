using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public static class DB
{
    public static string ConnStr
    {
        get { return ConfigurationManager.ConnectionStrings["LMSConn"].ConnectionString; }
    }

    public static DataTable Query(string sql, params SqlParameter[] ps)
    {
        using (var con = new SqlConnection(ConnStr))
        using (var cmd = new SqlCommand(sql, con))
        {
            if (ps != null) cmd.Parameters.AddRange(ps);
            con.Open();
            var dt = new DataTable();
            new SqlDataAdapter(cmd).Fill(dt);
            return dt;
        }
    }

    public static int Execute(string sql, params SqlParameter[] ps)
    {
        using (var con = new SqlConnection(ConnStr))
        using (var cmd = new SqlCommand(sql, con))
        {
            if (ps != null) cmd.Parameters.AddRange(ps);
            con.Open();
            return cmd.ExecuteNonQuery();
        }
    }

    public static object Scalar(string sql, params SqlParameter[] ps)
    {
        using (var con = new SqlConnection(ConnStr))
        using (var cmd = new SqlCommand(sql, con))
        {
            if (ps != null) cmd.Parameters.AddRange(ps);
            con.Open();
            return cmd.ExecuteScalar();
        }
    }

    public static SqlParameter P(string name, object val)
    {
        return new SqlParameter(name, val ?? DBNull.Value);
    }
}
