using System;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        litUsers.Text = DB.Scalar("SELECT COUNT(*) FROM Users").ToString();
        litCourses.Text = DB.Scalar("SELECT COUNT(*) FROM Courses").ToString();
        litEnrollments.Text = DB.Scalar("SELECT COUNT(*) FROM Enrollments").ToString();
        litAssignments.Text = DB.Scalar("SELECT COUNT(*) FROM Assignments").ToString();
        litDepts.Text = DB.Scalar("SELECT COUNT(*) FROM Departments").ToString();
        litSubs.Text = DB.Scalar("SELECT COUNT(*) FROM Submissions").ToString();

        var dt = DB.Query(
            "SELECT TOP 10 u.FirstName+' '+u.LastName AS Student, c.CourseName AS Course, " +
            "co.Semester, e.Status, e.EnrollmentDate " +
            "FROM Enrollments e " +
            "JOIN Users u ON e.StudentID=u.UserID " +
            "JOIN CourseOfferings co ON e.OfferingID=co.OfferingID " +
            "JOIN Courses c ON co.CourseID=c.CourseID " +
            "ORDER BY e.EnrollmentDate DESC");
        gvRecent.DataSource = dt;
        gvRecent.DataBind();
    }
}
