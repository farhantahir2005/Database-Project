<%@ Page Title="Messages" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true" CodeFile="Messages.aspx.cs" Inherits="Messages" %>
<asp:Content ContentPlaceHolderID="MainContent" runat="server">
<div class="page-title">Messages</div>
<div class="page-sub">Internal messaging between users</div>
<asp:Literal ID="litMsg" runat="server"/>
<div class="card">
    <div class="action-row">
        <span class="card-title" style="margin:0">All Messages</span>
        <button class="btn btn-primary btn-sm" onclick="showModal('addModal');return false;">+ New Message</button>
    </div>
    <table>
        <tr><th>From</th><th>To</th><th>Subject</th><th>Sent</th><th>Read</th><th>Actions</th></tr>
        <asp:Repeater ID="rptMsg" runat="server" OnItemCommand="rptMsg_ItemCommand">
            <ItemTemplate><tr>
                <td><%#Eval("SenderName")%></td>
                <td><%#Eval("ReceiverName")%></td>
                <td><%#Eval("Subject")%></td>
                <td style="font-size:12px;color:var(--muted)"><%#((DateTime)Eval("SentAt")).ToString("MMM dd HH:mm")%></td>
                <td><%#((bool)Eval("IsRead")?"<span class='badge badge-green'>Read</span>":"<span class='badge badge-blue'>Unread</span>")%></td>
                <td>
                    <asp:LinkButton CommandName="View" CommandArgument='<%#Eval("MessageID")%>' CssClass="btn btn-secondary btn-sm" runat="server">View</asp:LinkButton>
                    <asp:LinkButton CommandName="Delete" CommandArgument='<%#Eval("MessageID")%>' CssClass="btn btn-danger btn-sm" runat="server" OnClientClick="return confirm('Delete?')">Delete</asp:LinkButton>
                </td>
            </tr></ItemTemplate>
        </asp:Repeater>
    </table>
</div>
<div class="modal-overlay" id="addModal"><div class="modal">
    <div class="modal-title">New Message</div>
    <div class="form-grid">
        <div class="form-group"><label>From</label><asp:DropDownList ID="ddlSender" runat="server"/></div>
        <div class="form-group"><label>To</label><asp:DropDownList ID="ddlReceiver" runat="server"/></div>
        <div class="form-group full"><label>Subject</label><asp:TextBox ID="txtSubject" runat="server"/></div>
        <div class="form-group full"><label>Message</label><asp:TextBox ID="txtBody" runat="server" TextMode="MultiLine" style="min-height:120px"/></div>
    </div>
    <div class="modal-footer">
        <button class="btn btn-secondary" onclick="hideModal('addModal');return false;">Cancel</button>
        <asp:Button runat="server" Text="Send" CssClass="btn btn-primary" OnClick="btnSend_Click"/>
    </div>
</div></div>
<div class="modal-overlay" id="viewModal"><div class="modal">
    <div class="modal-title">Message</div>
    <asp:HiddenField ID="hfID" runat="server"/>
    <div style="margin-bottom:12px">
        <div style="font-size:12px;color:var(--muted);margin-bottom:4px">FROM / TO</div>
        <asp:Literal ID="litFromTo" runat="server"/>
    </div>
    <div style="margin-bottom:12px">
        <div style="font-size:12px;color:var(--muted);margin-bottom:4px">SUBJECT</div>
        <asp:Literal ID="litSubject" runat="server"/>
    </div>
    <div>
        <div style="font-size:12px;color:var(--muted);margin-bottom:4px">BODY</div>
        <div style="background:var(--bg);padding:16px;border-radius:8px;border:1px solid var(--border);font-size:14px;line-height:1.6">
            <asp:Literal ID="litBody" runat="server"/>
        </div>
    </div>
    <div class="modal-footer">
        <button class="btn btn-secondary" onclick="hideModal('viewModal');return false;">Close</button>
    </div>
</div></div>
<script>function showModal(id){document.getElementById(id).classList.add('show');}function hideModal(id){document.getElementById(id).classList.remove('show');}</script>
<asp:Literal ID="litViewScript" runat="server"/>
</asp:Content>
