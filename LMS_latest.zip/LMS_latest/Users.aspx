<%@ Page Title="Users" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true" CodeFile="Users.aspx.cs" Inherits="Users" %>
<asp:Content ContentPlaceHolderID="MainContent" runat="server">
<div class="page-title">Users</div>
<div class="page-sub">Manage students, teachers, and admins</div>

<asp:Literal ID="litMsg" runat="server"/>

<div class="card">
    <div class="action-row">
        <span class="card-title" style="margin:0">All Users</span>
        <button class="btn btn-primary btn-sm" onclick="showModal('addModal');return false;">+ Add User</button>
    </div>
    <table>
        <tr><th>Name</th><th>Email</th><th>Type</th><th>Phone</th><th>Active</th><th>Actions</th></tr>
        <asp:Repeater ID="rptUsers" runat="server" OnItemCommand="rptUsers_ItemCommand">
            <ItemTemplate>
                <tr>
                    <td><%#Eval("FirstName")%> <%#Eval("LastName")%></td>
                    <td><%#Eval("Email")%></td>
                    <td><span class='badge <%#(string)Eval("UserType")=="Admin"?"badge-red":(string)Eval("UserType")=="Teacher"?"badge-blue":"badge-green"%>'><%#Eval("UserType")%></span></td>
                    <td><%#Eval("Phone")%></td>
                    <td><%#((bool)Eval("IsActive")?"<span class='badge badge-green'>Yes</span>":"<span class='badge badge-gray'>No</span>")%></td>
                    <td>
                        <asp:LinkButton CommandName="Edit" CommandArgument='<%#Eval("UserID")%>' CssClass="btn btn-secondary btn-sm" runat="server">Edit</asp:LinkButton>
                        <asp:LinkButton CommandName="Delete" CommandArgument='<%#Eval("UserID")%>' CssClass="btn btn-danger btn-sm" runat="server"
                            OnClientClick="return confirm('Delete this user?')">Delete</asp:LinkButton>
                    </td>
                </tr>
            </ItemTemplate>
        </asp:Repeater>
    </table>
</div>

<!-- ADD MODAL -->
<div class="modal-overlay" id="addModal">
<div class="modal">
    <div class="modal-title">Add New User</div>
    <div class="form-grid">
        <div class="form-group"><label>First Name</label><asp:TextBox ID="txtFN" runat="server"/></div>
        <div class="form-group"><label>Last Name</label><asp:TextBox ID="txtLN" runat="server"/></div>
        <div class="form-group"><label>Email</label><asp:TextBox ID="txtEmail" runat="server" TextMode="Email"/></div>
        <div class="form-group"><label>Password</label><asp:TextBox ID="txtPwd" runat="server" TextMode="Password"/></div>
        <div class="form-group"><label>User Type</label>
            <asp:DropDownList ID="ddlType" runat="server">
                <asp:ListItem>Student</asp:ListItem><asp:ListItem>Teacher</asp:ListItem><asp:ListItem>Admin</asp:ListItem>
            </asp:DropDownList>
        </div>
        <div class="form-group"><label>Phone</label><asp:TextBox ID="txtPhone" runat="server"/></div>
        <div class="form-group"><label>Date of Birth</label><asp:TextBox ID="txtDOB" runat="server" TextMode="Date"/></div>
    </div>
    <div class="modal-footer">
        <button class="btn btn-secondary" onclick="hideModal('addModal');return false;">Cancel</button>
        <asp:Button ID="btnAdd" runat="server" Text="Add User" CssClass="btn btn-primary" OnClick="btnAdd_Click"/>
    </div>
</div>
</div>

<!-- EDIT MODAL -->
<div class="modal-overlay" id="editModal">
<div class="modal">
    <div class="modal-title">Edit User</div>
    <asp:HiddenField ID="hfEditID" runat="server"/>
    <div class="form-grid">
        <div class="form-group"><label>First Name</label><asp:TextBox ID="txtEFN" runat="server"/></div>
        <div class="form-group"><label>Last Name</label><asp:TextBox ID="txtELN" runat="server"/></div>
        <div class="form-group"><label>Email</label><asp:TextBox ID="txtEEmail" runat="server"/></div>
        <div class="form-group"><label>User Type</label>
            <asp:DropDownList ID="ddlEType" runat="server">
                <asp:ListItem>Student</asp:ListItem><asp:ListItem>Teacher</asp:ListItem><asp:ListItem>Admin</asp:ListItem>
            </asp:DropDownList>
        </div>
        <div class="form-group"><label>Phone</label><asp:TextBox ID="txtEPhone" runat="server"/></div>
        <div class="form-group"><label>Active</label>
            <asp:DropDownList ID="ddlEActive" runat="server">
                <asp:ListItem Value="1">Yes</asp:ListItem><asp:ListItem Value="0">No</asp:ListItem>
            </asp:DropDownList>
        </div>
    </div>
    <div class="modal-footer">
        <button class="btn btn-secondary" onclick="hideModal('editModal');return false;">Cancel</button>
        <asp:Button ID="btnUpdate" runat="server" Text="Save Changes" CssClass="btn btn-primary" OnClick="btnUpdate_Click"/>
    </div>
</div>
</div>

<script>
function showModal(id){document.getElementById(id).classList.add('show');}
function hideModal(id){document.getElementById(id).classList.remove('show');}
</script>
<asp:Literal ID="litEditScript" runat="server"/>
</asp:Content>
