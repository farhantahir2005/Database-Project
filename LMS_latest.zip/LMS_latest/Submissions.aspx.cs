using System;
using System.Web.UI.WebControls;

public partial class Submissions : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack) { LoadData(); BindStudents(); BindAssignments(); BindGraders(); }
    }

    void LoadData()
    {
        rptSub.DataSource = DB.Query(
            "SELECT sub.*,u.FirstName+' '+u.LastName AS StudentName,a.Title " +
            "FROM Submissions sub JOIN Users u ON sub.StudentID=u.UserID " +
            "JOIN Assignments a ON sub.AssignmentID=a.AssignmentID ORDER BY sub.SubmissionDate DESC");
        rptSub.DataBind();
    }

    void BindStudents()
    {
        ddlStudent.DataSource = DB.Query("SELECT UserID,FirstName+' '+LastName AS Name FROM Users WHERE UserType='Student'");
        ddlStudent.DataTextField = "Name";
        ddlStudent.DataValueField = "UserID";
        ddlStudent.DataBind();
    }

    void BindAssignments()
    {
        ddlAssign.DataSource = DB.Query("SELECT AssignmentID,Title FROM Assignments");
        ddlAssign.DataTextField = "Title";
        ddlAssign.DataValueField = "AssignmentID";
        ddlAssign.DataBind();
    }

    void BindGraders()
    {
        ddlGrader.DataSource = DB.Query("SELECT UserID,FirstName+' '+LastName AS Name FROM Users WHERE UserType IN('Teacher','Admin')");
        ddlGrader.DataTextField = "Name";
        ddlGrader.DataValueField = "UserID";
        ddlGrader.DataBind();
    }

    protected void btnAdd_Click(object sender, EventArgs e)
    {
        try
        {
            DB.ExecProcNQ("sp_AddSubmission",
                DB.P("@AssignmentID", ddlAssign.SelectedValue), DB.P("@StudentID", ddlStudent.SelectedValue),
                DB.P("@Content", txtContent.Text), DB.P("@Status", ddlStatus.SelectedValue));
            litMsg.Text = "<div class='alert alert-success'>Submission added.</div>";
        }
        catch (Exception ex)
        {
            litMsg.Text = "<div class='alert alert-danger'>Error: " + ex.Message + "</div>";
        }
        LoadData();
    }

    protected void rptSub_ItemCommand(object s, RepeaterCommandEventArgs e)
    {
        int id = int.Parse(e.CommandArgument.ToString());
        if (e.CommandName == "Delete")
        {
            DB.ExecProcNQ("sp_DeleteSubmission", DB.P("@SubmissionID", id));
            litMsg.Text = "<div class='alert alert-success'>Deleted.</div>";
            LoadData();
        }
        else if (e.CommandName == "Grade")
        {
            var r = DB.Query("SELECT * FROM Submissions WHERE SubmissionID=@id", DB.P("@id", id)).Rows[0];
            hfID.Value = id.ToString();
            if (r["MarksObtained"] != DBNull.Value)
                txtMarks.Text = r["MarksObtained"].ToString();
            txtFeedback.Text = r["Feedback"].ToString();
            ddlGStatus.SelectedValue = r["Status"].ToString();
            BindGraders();
            if (r["GradedBy"] != DBNull.Value)
                ddlGrader.SelectedValue = r["GradedBy"].ToString();
            litEditScript.Text = "<script>showModal('gradeModal');<" + "/script>";
        }
    }

    protected void btnGrade_Click(object sender, EventArgs e)
    {
        try
        {
            object marks = string.IsNullOrEmpty(txtMarks.Text) ? (object)DBNull.Value : (object)txtMarks.Text;
            DB.Execute("UPDATE Submissions SET MarksObtained=@m,Feedback=@f,Status=@st,GradedBy=@g,GradedAt=GETDATE() WHERE SubmissionID=@id",
                DB.P("@m", marks), DB.P("@f", txtFeedback.Text),
                DB.P("@st", ddlGStatus.SelectedValue), DB.P("@g", ddlGrader.SelectedValue),
                DB.P("@id", hfID.Value));
            litMsg.Text = "<div class='alert alert-success'>Graded successfully.</div>";
        }
        catch (Exception ex)
        {
            litMsg.Text = "<div class='alert alert-danger'>Error: " + ex.Message + "</div>";
        }
        LoadData();
    }
}
