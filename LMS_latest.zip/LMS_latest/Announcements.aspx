<%@ Page Title="Announcements" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true" CodeFile="Announcements.aspx.cs" Inherits="Announcements" %>
<asp:Content ContentPlaceHolderID="MainContent" runat="server">
<div class="page-title">Announcements</div>
<div class="page-sub">Course announcements and notices</div>
<asp:Literal ID="litMsg" runat="server"/>
<div class="card">
    <div class="action-row">
        <span class="card-title" style="margin:0">All Announcements</span>
        <button class="btn btn-primary btn-sm" onclick="showModal('addModal');return false;">+ Post Announcement</button>
    </div>
    <table>
        <tr><th>Title</th><th>Course</th><th>Posted By</th><th>Priority</th><th>Date</th><th>Active</th><th>Actions</th></tr>
        <asp:Repeater ID="rptAnn" runat="server" OnItemCommand="rptAnn_ItemCommand">
            <ItemTemplate><tr>
                <td><%#Eval("Title")%></td>
                <td><%#Eval("CourseName")%></td>
                <td><%#Eval("PosterName")%></td>
                <td><span class='badge <%#(string)Eval("Priority")=="Urgent"?"badge-red":(string)Eval("Priority")=="High"?"badge-blue":(string)Eval("Priority")=="Normal"?"badge-green":"badge-gray"%>'><%#Eval("Priority")%></span></td>
                <td style="font-size:12px;color:var(--muted)"><%#((DateTime)Eval("CreatedAt")).ToString("MMM dd, yyyy")%></td>
                <td><%#((bool)Eval("IsActive")?"<span class='badge badge-green'>Yes</span>":"<span class='badge badge-gray'>No</span>")%></td>
                <td>
                    <asp:LinkButton CommandName="Edit" CommandArgument='<%#Eval("AnnouncementID")%>' CssClass="btn btn-secondary btn-sm" runat="server">Edit</asp:LinkButton>
                    <asp:LinkButton CommandName="Delete" CommandArgument='<%#Eval("AnnouncementID")%>' CssClass="btn btn-danger btn-sm" runat="server" OnClientClick="return confirm('Delete?')">Delete</asp:LinkButton>
                </td>
            </tr></ItemTemplate>
        </asp:Repeater>
    </table>
</div>
<div class="modal-overlay" id="addModal"><div class="modal">
    <div class="modal-title">Post Announcement</div>
    <div class="form-grid">
        <div class="form-group full"><label>Title</label><asp:TextBox ID="txtTitle" runat="server"/></div>
        <div class="form-group"><label>Offering</label><asp:DropDownList ID="ddlOff" runat="server"/></div>
        <div class="form-group"><label>Posted By</label><asp:DropDownList ID="ddlPoster" runat="server"/></div>
        <div class="form-group"><label>Priority</label>
            <asp:DropDownList ID="ddlPriority" runat="server"><asp:ListItem>Low</asp:ListItem><asp:ListItem>Normal</asp:ListItem><asp:ListItem>High</asp:ListItem><asp:ListItem>Urgent</asp:ListItem></asp:DropDownList></div>
        <div class="form-group full"><label>Content</label><asp:TextBox ID="txtContent" runat="server" TextMode="MultiLine"/></div>
    </div>
    <div class="modal-footer">
        <button class="btn btn-secondary" onclick="hideModal('addModal');return false;">Cancel</button>
        <asp:Button runat="server" Text="Post" CssClass="btn btn-primary" OnClick="btnAdd_Click"/>
    </div>
</div></div>
<div class="modal-overlay" id="editModal"><div class="modal">
    <div class="modal-title">Edit Announcement</div>
    <asp:HiddenField ID="hfID" runat="server"/>
    <div class="form-grid">
        <div class="form-group full"><label>Title</label><asp:TextBox ID="txtETitle" runat="server"/></div>
        <div class="form-group"><label>Priority</label>
            <asp:DropDownList ID="ddlEPriority" runat="server"><asp:ListItem>Low</asp:ListItem><asp:ListItem>Normal</asp:ListItem><asp:ListItem>High</asp:ListItem><asp:ListItem>Urgent</asp:ListItem></asp:DropDownList></div>
        <div class="form-group"><label>Active</label>
            <asp:DropDownList ID="ddlEActive" runat="server"><asp:ListItem Value="1">Yes</asp:ListItem><asp:ListItem Value="0">No</asp:ListItem></asp:DropDownList></div>
        <div class="form-group full"><label>Content</label><asp:TextBox ID="txtEContent" runat="server" TextMode="MultiLine"/></div>
    </div>
    <div class="modal-footer">
        <button class="btn btn-secondary" onclick="hideModal('editModal');return false;">Cancel</button>
        <asp:Button runat="server" Text="Save" CssClass="btn btn-primary" OnClick="btnUpdate_Click"/>
    </div>
</div></div>
<script>function showModal(id){document.getElementById(id).classList.add('show');}function hideModal(id){document.getElementById(id).classList.remove('show');}</script>
<asp:Literal ID="litEditScript" runat="server"/>
</asp:Content>
