<%@ Page Title="Dashboard" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true" CodeFile="Default.aspx.cs" Inherits="_Default" %>
<asp:Content ContentPlaceHolderID="MainContent" runat="server">
    <div class="page-title">Dashboard</div>
    <div class="page-sub">Welcome to Flex LMS — system overview</div>

    <div class="stat-grid">
        <div class="stat-card">
            <div class="stat-label">Total Users</div>
            <div class="stat-value"><asp:Literal ID="litUsers" runat="server"/></div>
        </div>
        <div class="stat-card">
            <div class="stat-label">Courses</div>
            <div class="stat-value"><asp:Literal ID="litCourses" runat="server"/></div>
        </div>
        <div class="stat-card">
            <div class="stat-label">Enrollments</div>
            <div class="stat-value"><asp:Literal ID="litEnrollments" runat="server"/></div>
        </div>
        <div class="stat-card">
            <div class="stat-label">Assignments</div>
            <div class="stat-value"><asp:Literal ID="litAssignments" runat="server"/></div>
        </div>
        <div class="stat-card">
            <div class="stat-label">Departments</div>
            <div class="stat-value"><asp:Literal ID="litDepts" runat="server"/></div>
        </div>
        <div class="stat-card">
            <div class="stat-label">Submissions</div>
            <div class="stat-value"><asp:Literal ID="litSubs" runat="server"/></div>
        </div>
    </div>

    <div class="card">
        <div class="card-title">Recent Enrollments</div>
        <asp:GridView ID="gvRecent" runat="server" AutoGenerateColumns="false" CssClass="table" GridLines="None">
            <Columns>
                <asp:BoundField DataField="Student" HeaderText="Student"/>
                <asp:BoundField DataField="Course" HeaderText="Course"/>
                <asp:BoundField DataField="Semester" HeaderText="Semester"/>
                <asp:BoundField DataField="Status" HeaderText="Status"/>
                <asp:BoundField DataField="EnrollmentDate" HeaderText="Date" DataFormatString="{0:MMM dd, yyyy}"/>
            </Columns>
        </asp:GridView>
    </div>
</asp:Content>
