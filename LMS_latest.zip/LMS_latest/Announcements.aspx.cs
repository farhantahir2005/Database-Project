using System;
using System.Web.UI.WebControls;

public partial class Announcements : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack) { LoadData(); BindOfferings(); BindPosters(); }
    }

    void LoadData()
    {
        rptAnn.DataSource = DB.Query(
            "SELECT a.*,c.CourseName,u.FirstName+' '+u.LastName AS PosterName " +
            "FROM Announcements a JOIN CourseOfferings co ON a.OfferingID=co.OfferingID " +
            "JOIN Courses c ON co.CourseID=c.CourseID " +
            "JOIN Users u ON a.PostedBy=u.UserID ORDER BY a.CreatedAt DESC");
        rptAnn.DataBind();
    }

    void BindOfferings()
    {
        ddlOff.DataSource = DB.Query(
            "SELECT co.OfferingID,c.CourseCode+' '+co.Semester+' '+CAST(co.Year AS VARCHAR) AS Label " +
            "FROM CourseOfferings co JOIN Courses c ON co.CourseID=c.CourseID");
        ddlOff.DataTextField = "Label";
        ddlOff.DataValueField = "OfferingID";
        ddlOff.DataBind();
    }

    void BindPosters()
    {
        ddlPoster.DataSource = DB.Query("SELECT UserID,FirstName+' '+LastName AS Name FROM Users WHERE UserType IN('Teacher','Admin')");
        ddlPoster.DataTextField = "Name";
        ddlPoster.DataValueField = "UserID";
        ddlPoster.DataBind();
    }

    protected void btnAdd_Click(object sender, EventArgs e)
    {
        try
        {
            DB.Execute("INSERT INTO Announcements(OfferingID,PostedBy,Title,Content,Priority) VALUES(@o,@p,@t,@c,@pr)",
                DB.P("@o", ddlOff.SelectedValue), DB.P("@p", ddlPoster.SelectedValue),
                DB.P("@t", txtTitle.Text), DB.P("@c", txtContent.Text),
                DB.P("@pr", ddlPriority.SelectedValue));
            litMsg.Text = "<div class='alert alert-success'>Announcement posted.</div>";
        }
        catch (Exception ex)
        {
            litMsg.Text = "<div class='alert alert-danger'>Error: " + ex.Message + "</div>";
        }
        LoadData();
    }

    protected void rptAnn_ItemCommand(object s, RepeaterCommandEventArgs e)
    {
        int id = int.Parse(e.CommandArgument.ToString());
        if (e.CommandName == "Delete")
        {
            DB.Execute("DELETE FROM Announcements WHERE AnnouncementID=@id", DB.P("@id", id));
            litMsg.Text = "<div class='alert alert-success'>Deleted.</div>";
            LoadData();
        }
        else if (e.CommandName == "Edit")
        {
            var r = DB.Query("SELECT * FROM Announcements WHERE AnnouncementID=@id", DB.P("@id", id)).Rows[0];
            hfID.Value = id.ToString();
            txtETitle.Text = r["Title"].ToString();
            txtEContent.Text = r["Content"].ToString();
            ddlEPriority.SelectedValue = r["Priority"].ToString();
            ddlEActive.SelectedValue = r["IsActive"].ToString();
            litEditScript.Text = "<script>showModal('editModal');<" + "/script>";
        }
    }

    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        try
        {
            DB.Execute("UPDATE Announcements SET Title=@t,Content=@c,Priority=@pr,IsActive=@a WHERE AnnouncementID=@id",
                DB.P("@t", txtETitle.Text), DB.P("@c", txtEContent.Text),
                DB.P("@pr", ddlEPriority.SelectedValue), DB.P("@a", ddlEActive.SelectedValue),
                DB.P("@id", hfID.Value));
            litMsg.Text = "<div class='alert alert-success'>Updated.</div>";
        }
        catch (Exception ex)
        {
            litMsg.Text = "<div class='alert alert-danger'>Error: " + ex.Message + "</div>";
        }
        LoadData();
    }
}
