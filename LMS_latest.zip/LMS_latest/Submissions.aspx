<%@ Page Title="Submissions" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true" CodeFile="Submissions.aspx.cs" Inherits="Submissions" %>
<asp:Content ContentPlaceHolderID="MainContent" runat="server">
<div class="page-title">Submissions</div>
<div class="page-sub">View and grade student submissions</div>
<asp:Literal ID="litMsg" runat="server"/>
<div class="card">
    <div class="action-row">
        <span class="card-title" style="margin:0">All Submissions</span>
        <button class="btn btn-primary btn-sm" onclick="showModal('addModal');return false;">+ Add Submission</button>
    </div>
    <table>
        <tr><th>Student</th><th>Assignment</th><th>Submitted</th><th>Marks</th><th>Status</th><th>Feedback</th><th>Actions</th></tr>
        <asp:Repeater ID="rptSub" runat="server" OnItemCommand="rptSub_ItemCommand">
            <ItemTemplate><tr>
                <td><%#Eval("StudentName")%></td>
                <td><%#Eval("Title")%></td>
                <td style="font-size:12px;color:var(--muted)"><%#((DateTime)Eval("SubmissionDate")).ToString("MMM dd HH:mm")%></td>
                <td><%#Eval("MarksObtained") == DBNull.Value || Eval("MarksObtained") == null ? "--" : Eval("MarksObtained").ToString()%></td>
                <td><span class='badge <%#(string)Eval("Status")=="Graded"?"badge-green":(string)Eval("Status")=="Late"?"badge-red":"badge-blue"%>'><%#Eval("Status")%></span></td>
                <td style="font-size:12px;color:var(--muted);max-width:150px"><%#Eval("Feedback")%></td>
                <td>
                    <asp:LinkButton CommandName="Grade" CommandArgument='<%#Eval("SubmissionID")%>' CssClass="btn btn-secondary btn-sm" runat="server">Grade</asp:LinkButton>
                    <asp:LinkButton CommandName="Delete" CommandArgument='<%#Eval("SubmissionID")%>' CssClass="btn btn-danger btn-sm" runat="server" OnClientClick="return confirm('Delete?')">Delete</asp:LinkButton>
                </td>
            </tr></ItemTemplate>
        </asp:Repeater>
    </table>
</div>
<div class="modal-overlay" id="addModal"><div class="modal">
    <div class="modal-title">Add Submission</div>
    <div class="form-grid">
        <div class="form-group"><label>Student</label><asp:DropDownList ID="ddlStudent" runat="server"/></div>
        <div class="form-group"><label>Assignment</label><asp:DropDownList ID="ddlAssign" runat="server"/></div>
        <div class="form-group full"><label>Content / Notes</label><asp:TextBox ID="txtContent" runat="server" TextMode="MultiLine"/></div>
        <div class="form-group"><label>Status</label>
            <asp:DropDownList ID="ddlStatus" runat="server"><asp:ListItem>Submitted</asp:ListItem><asp:ListItem>Late</asp:ListItem></asp:DropDownList></div>
    </div>
    <div class="modal-footer">
        <button class="btn btn-secondary" onclick="hideModal('addModal');return false;">Cancel</button>
        <asp:Button runat="server" Text="Add" CssClass="btn btn-primary" OnClick="btnAdd_Click"/>
    </div>
</div></div>
<div class="modal-overlay" id="gradeModal"><div class="modal">
    <div class="modal-title">Grade Submission</div>
    <asp:HiddenField ID="hfID" runat="server"/>
    <div class="form-grid">
        <div class="form-group"><label>Marks Obtained</label><asp:TextBox ID="txtMarks" runat="server" TextMode="Number"/></div>
        <div class="form-group"><label>Status</label>
            <asp:DropDownList ID="ddlGStatus" runat="server"><asp:ListItem>Submitted</asp:ListItem><asp:ListItem>Graded</asp:ListItem><asp:ListItem>Late</asp:ListItem><asp:ListItem>Resubmitted</asp:ListItem></asp:DropDownList></div>
        <div class="form-group full"><label>Feedback</label><asp:TextBox ID="txtFeedback" runat="server" TextMode="MultiLine"/></div>
        <div class="form-group"><label>Graded By</label><asp:DropDownList ID="ddlGrader" runat="server"/></div>
    </div>
    <div class="modal-footer">
        <button class="btn btn-secondary" onclick="hideModal('gradeModal');return false;">Cancel</button>
        <asp:Button runat="server" Text="Save Grade" CssClass="btn btn-primary" OnClick="btnGrade_Click"/>
    </div>
</div></div>
<script>function showModal(id){document.getElementById(id).classList.add('show');}function hideModal(id){document.getElementById(id).classList.remove('show');}</script>
<asp:Literal ID="litEditScript" runat="server"/>
</asp:Content>
