using System;
using System.Web.UI.WebControls;

public partial class Attendance : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack) { LoadData(); BindStudents(); BindOfferings(); BindMarkers(); }
    }

    void LoadData()
    {
        rptAtt.DataSource = DB.Query(
            "SELECT a.*,u.FirstName+' '+u.LastName AS StudentName, " +
            "c.CourseName,m.FirstName+' '+m.LastName AS MarkedByName " +
            "FROM Attendance a JOIN Users u ON a.StudentID=u.UserID " +
            "JOIN CourseOfferings co ON a.OfferingID=co.OfferingID " +
            "JOIN Courses c ON co.CourseID=c.CourseID " +
            "LEFT JOIN Users m ON a.MarkedBy=m.UserID ORDER BY a.AttendanceDate DESC");
        rptAtt.DataBind();
    }

    void BindStudents()
    {
        ddlStudent.DataSource = DB.Query("SELECT UserID,FirstName+' '+LastName AS Name FROM Users WHERE UserType='Student'");
        ddlStudent.DataTextField = "Name";
        ddlStudent.DataValueField = "UserID";
        ddlStudent.DataBind();
    }

    void BindOfferings()
    {
        ddlOff.DataSource = DB.Query(
            "SELECT co.OfferingID,c.CourseCode+' '+co.Semester+' '+CAST(co.Year AS VARCHAR) AS Label " +
            "FROM CourseOfferings co JOIN Courses c ON co.CourseID=c.CourseID");
        ddlOff.DataTextField = "Label";
        ddlOff.DataValueField = "OfferingID";
        ddlOff.DataBind();
    }

    void BindMarkers()
    {
        ddlMarker.DataSource = DB.Query("SELECT UserID,FirstName+' '+LastName AS Name FROM Users WHERE UserType IN('Teacher','Admin')");
        ddlMarker.DataTextField = "Name";
        ddlMarker.DataValueField = "UserID";
        ddlMarker.DataBind();
    }

    protected void btnAdd_Click(object sender, EventArgs e)
    {
        try
        {
            DB.Execute("INSERT INTO Attendance(OfferingID,StudentID,AttendanceDate,Status,Remarks,MarkedBy) VALUES(@o,@st,@d,@ss,@r,@m)",
                DB.P("@o", ddlOff.SelectedValue), DB.P("@st", ddlStudent.SelectedValue),
                DB.P("@d", txtDate.Text), DB.P("@ss", ddlStatus.SelectedValue),
                DB.P("@r", txtRemarks.Text), DB.P("@m", ddlMarker.SelectedValue));
            litMsg.Text = "<div class='alert alert-success'>Attendance marked.</div>";
        }
        catch (Exception ex)
        {
            litMsg.Text = "<div class='alert alert-danger'>Error: " + ex.Message + "</div>";
        }
        LoadData();
    }

    protected void rptAtt_ItemCommand(object s, RepeaterCommandEventArgs e)
    {
        int id = int.Parse(e.CommandArgument.ToString());
        if (e.CommandName == "Delete")
        {
            DB.Execute("DELETE FROM Attendance WHERE AttendanceID=@id", DB.P("@id", id));
            litMsg.Text = "<div class='alert alert-success'>Deleted.</div>";
            LoadData();
        }
        else if (e.CommandName == "Edit")
        {
            var r = DB.Query("SELECT * FROM Attendance WHERE AttendanceID=@id", DB.P("@id", id)).Rows[0];
            hfID.Value = id.ToString();
            ddlEStatus.SelectedValue = r["Status"].ToString();
            txtERemarks.Text = r["Remarks"].ToString();
            litEditScript.Text = "<script>showModal('editModal');<" + "/script>";
        }
    }

    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        try
        {
            DB.Execute("UPDATE Attendance SET Status=@ss,Remarks=@r WHERE AttendanceID=@id",
                DB.P("@ss", ddlEStatus.SelectedValue),
                DB.P("@r", txtERemarks.Text),
                DB.P("@id", hfID.Value));
            litMsg.Text = "<div class='alert alert-success'>Updated.</div>";
        }
        catch (Exception ex)
        {
            litMsg.Text = "<div class='alert alert-danger'>Error: " + ex.Message + "</div>";
        }
        LoadData();
    }
}
