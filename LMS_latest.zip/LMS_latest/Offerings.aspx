<%@ Page Title="Course Offerings" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true" CodeFile="Offerings.aspx.cs" Inherits="Offerings" %>
<asp:Content ContentPlaceHolderID="MainContent" runat="server">
<div class="page-title">Course Offerings</div>
<div class="page-sub">Schedule courses per semester</div>
<asp:Literal ID="litMsg" runat="server"/>
<div class="card">
    <div class="action-row">
        <span class="card-title" style="margin:0">All Offerings</span>
        <button class="btn btn-primary btn-sm" onclick="showModal('addModal');return false;">+ Add Offering</button>
    </div>
    <table>
        <tr><th>Course</th><th>Teacher</th><th>Semester</th><th>Year</th><th>Section</th><th>Schedule</th><th>Classroom</th><th>Capacity</th><th>Actions</th></tr>
        <asp:Repeater ID="rptOff" runat="server" OnItemCommand="rptOff_ItemCommand">
            <ItemTemplate><tr>
                <td><%#Eval("CourseName")%> <span class="badge badge-blue"><%#Eval("CourseCode")%></span></td>
                <td><%#Eval("TeacherName")%></td>
                <td><%#Eval("Semester")%></td><td><%#Eval("Year")%></td><td><%#Eval("Section")%></td>
                <td style="font-size:12px;color:var(--muted)"><%#Eval("Schedule")%></td>
                <td><%#Eval("Classroom")%></td><td><%#Eval("MaxCapacity")%></td>
                <td>
                    <asp:LinkButton CommandName="Edit" CommandArgument='<%#Eval("OfferingID")%>' CssClass="btn btn-secondary btn-sm" runat="server">Edit</asp:LinkButton>
                    <asp:LinkButton CommandName="Delete" CommandArgument='<%#Eval("OfferingID")%>' CssClass="btn btn-danger btn-sm" runat="server" OnClientClick="return confirm('Delete?')">Delete</asp:LinkButton>
                </td>
            </tr></ItemTemplate>
        </asp:Repeater>
    </table>
</div>
<div class="modal-overlay" id="addModal"><div class="modal">
    <div class="modal-title">Add Offering</div>
    <div class="form-grid">
        <div class="form-group"><label>Course</label><asp:DropDownList ID="ddlCourse" runat="server"/></div>
        <div class="form-group"><label>Teacher</label><asp:DropDownList ID="ddlTeacher" runat="server"/></div>
        <div class="form-group"><label>Semester</label>
            <asp:DropDownList ID="ddlSem" runat="server"><asp:ListItem>Fall</asp:ListItem><asp:ListItem>Spring</asp:ListItem><asp:ListItem>Summer</asp:ListItem></asp:DropDownList></div>
        <div class="form-group"><label>Year</label><asp:TextBox ID="txtYear" runat="server" Text="2026"/></div>
        <div class="form-group"><label>Section</label><asp:TextBox ID="txtSec" runat="server"/></div>
        <div class="form-group"><label>Max Capacity</label><asp:TextBox ID="txtCap" runat="server" TextMode="Number"/></div>
        <div class="form-group full"><label>Schedule</label><asp:TextBox ID="txtSched" runat="server" placeholder="e.g. MWF 10:00-11:00"/></div>
        <div class="form-group"><label>Classroom</label><asp:TextBox ID="txtRoom" runat="server"/></div>
        <div class="form-group"><label>Start Date</label><asp:TextBox ID="txtStart" runat="server" TextMode="Date"/></div>
        <div class="form-group"><label>End Date</label><asp:TextBox ID="txtEnd" runat="server" TextMode="Date"/></div>
    </div>
    <div class="modal-footer">
        <button class="btn btn-secondary" onclick="hideModal('addModal');return false;">Cancel</button>
        <asp:Button runat="server" Text="Add" CssClass="btn btn-primary" OnClick="btnAdd_Click"/>
    </div>
</div></div>
<div class="modal-overlay" id="editModal"><div class="modal">
    <div class="modal-title">Edit Offering</div>
    <asp:HiddenField ID="hfID" runat="server"/>
    <div class="form-grid">
        <div class="form-group"><label>Course</label><asp:DropDownList ID="ddlECourse" runat="server"/></div>
        <div class="form-group"><label>Teacher</label><asp:DropDownList ID="ddlETeacher" runat="server"/></div>
        <div class="form-group"><label>Semester</label>
            <asp:DropDownList ID="ddlESem" runat="server"><asp:ListItem>Fall</asp:ListItem><asp:ListItem>Spring</asp:ListItem><asp:ListItem>Summer</asp:ListItem></asp:DropDownList></div>
        <div class="form-group"><label>Year</label><asp:TextBox ID="txtEYear" runat="server"/></div>
        <div class="form-group"><label>Section</label><asp:TextBox ID="txtESec" runat="server"/></div>
        <div class="form-group"><label>Max Capacity</label><asp:TextBox ID="txtECap" runat="server"/></div>
        <div class="form-group full"><label>Schedule</label><asp:TextBox ID="txtESched" runat="server"/></div>
        <div class="form-group"><label>Classroom</label><asp:TextBox ID="txtERoom" runat="server"/></div>
        <div class="form-group"><label>Start Date</label><asp:TextBox ID="txtEStart" runat="server" TextMode="Date"/></div>
        <div class="form-group"><label>End Date</label><asp:TextBox ID="txtEEnd" runat="server" TextMode="Date"/></div>
    </div>
    <div class="modal-footer">
        <button class="btn btn-secondary" onclick="hideModal('editModal');return false;">Cancel</button>
        <asp:Button runat="server" Text="Save" CssClass="btn btn-primary" OnClick="btnUpdate_Click"/>
    </div>
</div></div>
<script>function showModal(id){document.getElementById(id).classList.add('show');}function hideModal(id){document.getElementById(id).classList.remove('show');}</script>
<asp:Literal ID="litEditScript" runat="server"/>
</asp:Content>
