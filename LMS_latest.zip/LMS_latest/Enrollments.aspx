<%@ Page Title="Enrollments" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true" CodeFile="Enrollments.aspx.cs" Inherits="Enrollments" %>
<asp:Content ContentPlaceHolderID="MainContent" runat="server">
<div class="page-title">Enrollments</div>
<div class="page-sub">Manage student enrollments in course offerings</div>
<asp:Literal ID="litMsg" runat="server"/>
<div class="card">
    <div class="action-row">
        <span class="card-title" style="margin:0">All Enrollments</span>
        <button class="btn btn-primary btn-sm" onclick="showModal('addModal');return false;">+ Enroll Student</button>
    </div>
    <table>
        <tr><th>Student</th><th>Course</th><th>Semester</th><th>Grade</th><th>Status</th><th>Enrolled</th><th>Actions</th></tr>
        <asp:Repeater ID="rptEnroll" runat="server" OnItemCommand="rptEnroll_ItemCommand">
            <ItemTemplate><tr>
                <td><%#Eval("StudentName")%></td>
                <td><%#Eval("CourseName")%></td>
                <td><%#Eval("Semester")%> <%#Eval("Year")%></td>
                <td><%#Eval("Grade") == DBNull.Value || Eval("Grade") == null ? "<span class='badge badge-gray'>--</span>" : "<span class='badge badge-blue'>" + Eval("Grade") + "</span>"%></td>
                <td><span class='badge <%#(string)Eval("Status")=="Active"?"badge-green":(string)Eval("Status")=="Completed"?"badge-blue":"badge-red"%>'><%#Eval("Status")%></span></td>
                <td style="font-size:12px;color:var(--muted)"><%#((DateTime)Eval("EnrollmentDate")).ToString("MMM dd, yyyy")%></td>
                <td>
                    <asp:LinkButton CommandName="Edit" CommandArgument='<%#Eval("EnrollmentID")%>' CssClass="btn btn-secondary btn-sm" runat="server">Edit</asp:LinkButton>
                    <asp:LinkButton CommandName="Delete" CommandArgument='<%#Eval("EnrollmentID")%>' CssClass="btn btn-danger btn-sm" runat="server" OnClientClick="return confirm('Remove enrollment?')">Remove</asp:LinkButton>
                </td>
            </tr></ItemTemplate>
        </asp:Repeater>
    </table>
</div>
<div class="modal-overlay" id="addModal"><div class="modal">
    <div class="modal-title">Enroll Student</div>
    <div class="form-grid">
        <div class="form-group"><label>Student</label><asp:DropDownList ID="ddlStudent" runat="server"/></div>
        <div class="form-group"><label>Course Offering</label><asp:DropDownList ID="ddlOffering" runat="server"/></div>
        <div class="form-group"><label>Status</label>
            <asp:DropDownList ID="ddlStatus" runat="server"><asp:ListItem>Active</asp:ListItem><asp:ListItem>Dropped</asp:ListItem><asp:ListItem>Completed</asp:ListItem><asp:ListItem>Withdrawn</asp:ListItem></asp:DropDownList></div>
        <div class="form-group"><label>Grade (optional)</label>
            <asp:DropDownList ID="ddlGrade" runat="server">
                <asp:ListItem Value="">— None —</asp:ListItem><asp:ListItem>A+</asp:ListItem><asp:ListItem>A</asp:ListItem><asp:ListItem>A-</asp:ListItem>
                <asp:ListItem>B+</asp:ListItem><asp:ListItem>B</asp:ListItem><asp:ListItem>B-</asp:ListItem>
                <asp:ListItem>C+</asp:ListItem><asp:ListItem>C</asp:ListItem><asp:ListItem>C-</asp:ListItem>
                <asp:ListItem>D</asp:ListItem><asp:ListItem>F</asp:ListItem><asp:ListItem>W</asp:ListItem>
            </asp:DropDownList></div>
    </div>
    <div class="modal-footer">
        <button class="btn btn-secondary" onclick="hideModal('addModal');return false;">Cancel</button>
        <asp:Button runat="server" Text="Enroll" CssClass="btn btn-primary" OnClick="btnAdd_Click"/>
    </div>
</div></div>
<div class="modal-overlay" id="editModal"><div class="modal">
    <div class="modal-title">Edit Enrollment</div>
    <asp:HiddenField ID="hfID" runat="server"/>
    <div class="form-grid">
        <div class="form-group"><label>Status</label>
            <asp:DropDownList ID="ddlEStatus" runat="server"><asp:ListItem>Active</asp:ListItem><asp:ListItem>Dropped</asp:ListItem><asp:ListItem>Completed</asp:ListItem><asp:ListItem>Withdrawn</asp:ListItem></asp:DropDownList></div>
        <div class="form-group"><label>Grade</label>
            <asp:DropDownList ID="ddlEGrade" runat="server">
                <asp:ListItem Value="">— None —</asp:ListItem><asp:ListItem>A+</asp:ListItem><asp:ListItem>A</asp:ListItem><asp:ListItem>A-</asp:ListItem>
                <asp:ListItem>B+</asp:ListItem><asp:ListItem>B</asp:ListItem><asp:ListItem>B-</asp:ListItem>
                <asp:ListItem>C+</asp:ListItem><asp:ListItem>C</asp:ListItem><asp:ListItem>C-</asp:ListItem>
                <asp:ListItem>D</asp:ListItem><asp:ListItem>F</asp:ListItem><asp:ListItem>W</asp:ListItem>
            </asp:DropDownList></div>
    </div>
    <div class="modal-footer">
        <button class="btn btn-secondary" onclick="hideModal('editModal');return false;">Cancel</button>
        <asp:Button runat="server" Text="Save" CssClass="btn btn-primary" OnClick="btnUpdate_Click"/>
    </div>
</div></div>
<script>function showModal(id){document.getElementById(id).classList.add('show');}function hideModal(id){document.getElementById(id).classList.remove('show');}</script>
<asp:Literal ID="litEditScript" runat="server"/>
</asp:Content>
