<%@ Page Title="Departments" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true" CodeFile="Departments.aspx.cs" Inherits="Departments" %>
<asp:Content ContentPlaceHolderID="MainContent" runat="server">
<div class="page-title">Departments</div>
<div class="page-sub">Manage academic departments</div>
<asp:Literal ID="litMsg" runat="server"/>
<div class="card">
    <div class="action-row">
        <span class="card-title" style="margin:0">All Departments</span>
        <button class="btn btn-primary btn-sm" onclick="showModal('addModal');return false;">+ Add Department</button>
    </div>
    <table>
        <tr><th>Name</th><th>Code</th><th>Head</th><th>Description</th><th>Actions</th></tr>
        <asp:Repeater ID="rptDepts" runat="server" OnItemCommand="rptDepts_ItemCommand">
            <ItemTemplate>
                <tr>
                    <td><%#Eval("DepartmentName")%></td>
                    <td><span class="badge badge-blue"><%#Eval("DepartmentCode")%></span></td>
                    <td><%#Eval("HeadName")%></td>
                    <td style="color:var(--muted);font-size:12px"><%#Eval("Description")%></td>
                    <td>
                        <asp:LinkButton CommandName="Edit" CommandArgument='<%#Eval("DepartmentID")%>' CssClass="btn btn-secondary btn-sm" runat="server">Edit</asp:LinkButton>
                        <asp:LinkButton CommandName="Delete" CommandArgument='<%#Eval("DepartmentID")%>' CssClass="btn btn-danger btn-sm" runat="server" OnClientClick="return confirm('Delete?')">Delete</asp:LinkButton>
                    </td>
                </tr>
            </ItemTemplate>
        </asp:Repeater>
    </table>
</div>
<!-- ADD -->
<div class="modal-overlay" id="addModal">
<div class="modal">
    <div class="modal-title">Add Department</div>
    <div class="form-grid">
        <div class="form-group"><label>Department Name</label><asp:TextBox ID="txtName" runat="server"/></div>
        <div class="form-group"><label>Code</label><asp:TextBox ID="txtCode" runat="server"/></div>
        <div class="form-group"><label>Head of Department</label>
            <asp:DropDownList ID="ddlHead" runat="server"/></div>
        <div class="form-group full"><label>Description</label><asp:TextBox ID="txtDesc" runat="server" TextMode="MultiLine"/></div>
    </div>
    <div class="modal-footer">
        <button class="btn btn-secondary" onclick="hideModal('addModal');return false;">Cancel</button>
        <asp:Button runat="server" Text="Add" CssClass="btn btn-primary" OnClick="btnAdd_Click"/>
    </div>
</div></div>
<!-- EDIT -->
<div class="modal-overlay" id="editModal">
<div class="modal">
    <div class="modal-title">Edit Department</div>
    <asp:HiddenField ID="hfID" runat="server"/>
    <div class="form-grid">
        <div class="form-group"><label>Name</label><asp:TextBox ID="txtEName" runat="server"/></div>
        <div class="form-group"><label>Code</label><asp:TextBox ID="txtECode" runat="server"/></div>
        <div class="form-group"><label>Head</label><asp:DropDownList ID="ddlEHead" runat="server"/></div>
        <div class="form-group full"><label>Description</label><asp:TextBox ID="txtEDesc" runat="server" TextMode="MultiLine"/></div>
    </div>
    <div class="modal-footer">
        <button class="btn btn-secondary" onclick="hideModal('editModal');return false;">Cancel</button>
        <asp:Button runat="server" Text="Save" CssClass="btn btn-primary" OnClick="btnUpdate_Click"/>
    </div>
</div></div>
<script>function showModal(id){document.getElementById(id).classList.add('show');}function hideModal(id){document.getElementById(id).classList.remove('show');}</script>
<asp:Literal ID="litEditScript" runat="server"/>
</asp:Content>
