using System;
using System.Data;
using System.Web.UI.WebControls;

public partial class Departments : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack) { LoadData(); PopulateHeads(ddlHead); PopulateHeads(ddlEHead); }
    }

    void LoadData()
    {
        rptDepts.DataSource = DB.Query(
            "SELECT d.*, ISNULL(u.FirstName+' '+u.LastName,'--') AS HeadName " +
            "FROM Departments d LEFT JOIN Users u ON d.HeadOfDepartment=u.UserID ORDER BY d.DepartmentID");
        rptDepts.DataBind();
    }

    void PopulateHeads(DropDownList ddl)
    {
        ddl.DataSource = DB.Query("SELECT UserID, FirstName+' '+LastName AS Name FROM Users WHERE UserType IN('Teacher','Admin')");
        ddl.DataTextField = "Name";
        ddl.DataValueField = "UserID";
        ddl.DataBind();
        ddl.Items.Insert(0, new ListItem("-- None --", ""));
    }

    protected void btnAdd_Click(object sender, EventArgs e)
    {
        try
        {
            object head = string.IsNullOrEmpty(ddlHead.SelectedValue) ? (object)DBNull.Value : (object)int.Parse(ddlHead.SelectedValue);
            DB.Execute("INSERT INTO Departments(DepartmentName,DepartmentCode,HeadOfDepartment,Description) VALUES(@n,@c,@h,@d)",
                DB.P("@n", txtName.Text), DB.P("@c", txtCode.Text),
                DB.P("@h", head), DB.P("@d", txtDesc.Text));
            litMsg.Text = "<div class='alert alert-success'>Department added.</div>";
        }
        catch (Exception ex)
        {
            litMsg.Text = "<div class='alert alert-danger'>Error: " + ex.Message + "</div>";
        }
        LoadData();
    }

    protected void rptDepts_ItemCommand(object s, RepeaterCommandEventArgs e)
    {
        int id = int.Parse(e.CommandArgument.ToString());
        if (e.CommandName == "Delete")
        {
            DB.Execute("DELETE FROM Departments WHERE DepartmentID=@id", DB.P("@id", id));
            litMsg.Text = "<div class='alert alert-success'>Deleted.</div>";
            LoadData();
        }
        else if (e.CommandName == "Edit")
        {
            var r = DB.Query("SELECT * FROM Departments WHERE DepartmentID=@id", DB.P("@id", id)).Rows[0];
            hfID.Value = id.ToString();
            txtEName.Text = r["DepartmentName"].ToString();
            txtECode.Text = r["DepartmentCode"].ToString();
            txtEDesc.Text = r["Description"].ToString();
            PopulateHeads(ddlEHead);
            if (r["HeadOfDepartment"] != DBNull.Value)
                ddlEHead.SelectedValue = r["HeadOfDepartment"].ToString();
            litEditScript.Text = "<script>showModal('editModal');<" + "/script>";
        }
    }

    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        try
        {
            object head = string.IsNullOrEmpty(ddlEHead.SelectedValue) ? (object)DBNull.Value : (object)int.Parse(ddlEHead.SelectedValue);
            DB.Execute("UPDATE Departments SET DepartmentName=@n,DepartmentCode=@c,HeadOfDepartment=@h,Description=@d WHERE DepartmentID=@id",
                DB.P("@n", txtEName.Text), DB.P("@c", txtECode.Text),
                DB.P("@h", head), DB.P("@d", txtEDesc.Text), DB.P("@id", hfID.Value));
            litMsg.Text = "<div class='alert alert-success'>Updated.</div>";
        }
        catch (Exception ex)
        {
            litMsg.Text = "<div class='alert alert-danger'>Error: " + ex.Message + "</div>";
        }
        LoadData();
    }
}
