using System;
using System.Web.UI.WebControls;

public partial class Offerings : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack) { LoadData(); BindCourses(ddlCourse); BindCourses(ddlECourse); BindTeachers(ddlTeacher); BindTeachers(ddlETeacher); }
    }

    void LoadData()
    {
        rptOff.DataSource = DB.Query(
            "SELECT co.*,c.CourseName,c.CourseCode,u.FirstName+' '+u.LastName AS TeacherName " +
            "FROM CourseOfferings co JOIN Courses c ON co.CourseID=c.CourseID " +
            "JOIN Users u ON co.TeacherID=u.UserID ORDER BY co.OfferingID DESC");
        rptOff.DataBind();
    }

    void BindCourses(DropDownList ddl)
    {
        ddl.DataSource = DB.Query("SELECT CourseID,CourseCode+' - '+CourseName AS CN FROM Courses WHERE IsActive=1");
        ddl.DataTextField = "CN";
        ddl.DataValueField = "CourseID";
        ddl.DataBind();
    }

    void BindTeachers(DropDownList ddl)
    {
        ddl.DataSource = DB.Query("SELECT UserID,FirstName+' '+LastName AS Name FROM Users WHERE UserType='Teacher'");
        ddl.DataTextField = "Name";
        ddl.DataValueField = "UserID";
        ddl.DataBind();
    }

    protected void btnAdd_Click(object sender, EventArgs e)
    {
        try
        {
            DB.Execute("INSERT INTO CourseOfferings(CourseID,TeacherID,Semester,Year,Section,MaxCapacity,Schedule,Classroom,StartDate,EndDate) VALUES(@c,@t,@sm,@y,@sc,@cap,@sch,@r,@sd,@ed)",
                DB.P("@c", ddlCourse.SelectedValue), DB.P("@t", ddlTeacher.SelectedValue),
                DB.P("@sm", ddlSem.SelectedValue), DB.P("@y", txtYear.Text),
                DB.P("@sc", txtSec.Text), DB.P("@cap", txtCap.Text),
                DB.P("@sch", txtSched.Text), DB.P("@r", txtRoom.Text),
                DB.P("@sd", txtStart.Text), DB.P("@ed", txtEnd.Text));
            litMsg.Text = "<div class='alert alert-success'>Offering added.</div>";
        }
        catch (Exception ex)
        {
            litMsg.Text = "<div class='alert alert-danger'>Error: " + ex.Message + "</div>";
        }
        LoadData();
    }

    protected void rptOff_ItemCommand(object s, RepeaterCommandEventArgs e)
    {
        int id = int.Parse(e.CommandArgument.ToString());
        if (e.CommandName == "Delete")
        {
            DB.Execute("DELETE FROM CourseOfferings WHERE OfferingID=@id", DB.P("@id", id));
            litMsg.Text = "<div class='alert alert-success'>Deleted.</div>";
            LoadData();
        }
        else if (e.CommandName == "Edit")
        {
            var r = DB.Query("SELECT * FROM CourseOfferings WHERE OfferingID=@id", DB.P("@id", id)).Rows[0];
            hfID.Value = id.ToString();
            txtEYear.Text = r["Year"].ToString();
            txtESec.Text = r["Section"].ToString();
            txtECap.Text = r["MaxCapacity"].ToString();
            txtESched.Text = r["Schedule"].ToString();
            txtERoom.Text = r["Classroom"].ToString();
            if (r["StartDate"] != DBNull.Value)
                txtEStart.Text = ((DateTime)r["StartDate"]).ToString("yyyy-MM-dd");
            if (r["EndDate"] != DBNull.Value)
                txtEEnd.Text = ((DateTime)r["EndDate"]).ToString("yyyy-MM-dd");
            BindCourses(ddlECourse);
            ddlECourse.SelectedValue = r["CourseID"].ToString();
            BindTeachers(ddlETeacher);
            ddlETeacher.SelectedValue = r["TeacherID"].ToString();
            ddlESem.SelectedValue = r["Semester"].ToString();
            litEditScript.Text = "<script>showModal('editModal');<" + "/script>";
        }
    }

    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        try
        {
            DB.Execute("UPDATE CourseOfferings SET CourseID=@c,TeacherID=@t,Semester=@sm,Year=@y,Section=@sc,MaxCapacity=@cap,Schedule=@sch,Classroom=@r,StartDate=@sd,EndDate=@ed WHERE OfferingID=@id",
                DB.P("@c", ddlECourse.SelectedValue), DB.P("@t", ddlETeacher.SelectedValue),
                DB.P("@sm", ddlESem.SelectedValue), DB.P("@y", txtEYear.Text),
                DB.P("@sc", txtESec.Text), DB.P("@cap", txtECap.Text),
                DB.P("@sch", txtESched.Text), DB.P("@r", txtERoom.Text),
                DB.P("@sd", txtEStart.Text), DB.P("@ed", txtEEnd.Text),
                DB.P("@id", hfID.Value));
            litMsg.Text = "<div class='alert alert-success'>Updated.</div>";
        }
        catch (Exception ex)
        {
            litMsg.Text = "<div class='alert alert-danger'>Error: " + ex.Message + "</div>";
        }
        LoadData();
    }
}
