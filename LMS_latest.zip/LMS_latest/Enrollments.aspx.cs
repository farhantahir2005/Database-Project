using System;
using System.Web.UI.WebControls;

public partial class Enrollments : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack) { LoadData(); BindStudents(ddlStudent); BindOfferings(ddlOffering); }
    }

    void LoadData()
    {
        rptEnroll.DataSource = DB.Query(
            "SELECT e.*,u.FirstName+' '+u.LastName AS StudentName, " +
            "c.CourseName,co.Semester,co.Year FROM Enrollments e " +
            "JOIN Users u ON e.StudentID=u.UserID " +
            "JOIN CourseOfferings co ON e.OfferingID=co.OfferingID " +
            "JOIN Courses c ON co.CourseID=c.CourseID ORDER BY e.EnrollmentID DESC");
        rptEnroll.DataBind();
    }

    void BindStudents(DropDownList ddl)
    {
        ddl.DataSource = DB.Query("SELECT UserID,FirstName+' '+LastName AS Name FROM Users WHERE UserType='Student'");
        ddl.DataTextField = "Name";
        ddl.DataValueField = "UserID";
        ddl.DataBind();
    }

    void BindOfferings(DropDownList ddl)
    {
        ddl.DataSource = DB.Query(
            "SELECT co.OfferingID,c.CourseCode+' '+co.Semester+' '+CAST(co.Year AS VARCHAR) AS Label " +
            "FROM CourseOfferings co JOIN Courses c ON co.CourseID=c.CourseID");
        ddl.DataTextField = "Label";
        ddl.DataValueField = "OfferingID";
        ddl.DataBind();
    }

    protected void btnAdd_Click(object sender, EventArgs e)
    {
        try
        {
            object grade = string.IsNullOrEmpty(ddlGrade.SelectedValue) ? (object)DBNull.Value : (object)ddlGrade.SelectedValue;
            DB.Execute("INSERT INTO Enrollments(StudentID,OfferingID,Status,Grade) VALUES(@s,@o,@st,@g)",
                DB.P("@s", ddlStudent.SelectedValue), DB.P("@o", ddlOffering.SelectedValue),
                DB.P("@st", ddlStatus.SelectedValue), DB.P("@g", grade));
            litMsg.Text = "<div class='alert alert-success'>Student enrolled.</div>";
        }
        catch (Exception ex)
        {
            litMsg.Text = "<div class='alert alert-danger'>Error: " + ex.Message + "</div>";
        }
        LoadData();
    }

    protected void rptEnroll_ItemCommand(object s, RepeaterCommandEventArgs e)
    {
        int id = int.Parse(e.CommandArgument.ToString());
        if (e.CommandName == "Delete")
        {
            DB.Execute("DELETE FROM Enrollments WHERE EnrollmentID=@id", DB.P("@id", id));
            litMsg.Text = "<div class='alert alert-success'>Removed.</div>";
            LoadData();
        }
        else if (e.CommandName == "Edit")
        {
            var r = DB.Query("SELECT * FROM Enrollments WHERE EnrollmentID=@id", DB.P("@id", id)).Rows[0];
            hfID.Value = id.ToString();
            ddlEStatus.SelectedValue = r["Status"].ToString();
            if (r["Grade"] != DBNull.Value)
                ddlEGrade.SelectedValue = r["Grade"].ToString();
            litEditScript.Text = "<script>showModal('editModal');<" + "/script>";
        }
    }

    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        try
        {
            object grade = string.IsNullOrEmpty(ddlEGrade.SelectedValue) ? (object)DBNull.Value : (object)ddlEGrade.SelectedValue;
            DB.Execute("UPDATE Enrollments SET Status=@st,Grade=@g WHERE EnrollmentID=@id",
                DB.P("@st", ddlEStatus.SelectedValue),
                DB.P("@g", grade),
                DB.P("@id", hfID.Value));
            litMsg.Text = "<div class='alert alert-success'>Updated.</div>";
        }
        catch (Exception ex)
        {
            litMsg.Text = "<div class='alert alert-danger'>Error: " + ex.Message + "</div>";
        }
        LoadData();
    }
}
