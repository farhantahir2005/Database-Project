<%@ Page Title="Assignments" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true" CodeFile="Assignments.aspx.cs" Inherits="Assignments" %>
<asp:Content ContentPlaceHolderID="MainContent" runat="server">
<div class="page-title">Assignments</div>
<div class="page-sub">Manage course assignments and quizzes</div>
<asp:Literal ID="litMsg" runat="server"/>
<div class="card">
    <div class="action-row">
        <span class="card-title" style="margin:0">All Assignments</span>
        <button class="btn btn-primary btn-sm" onclick="showModal('addModal');return false;">+ Add Assignment</button>
    </div>
    <table>
        <tr><th>Title</th><th>Course</th><th>Type</th><th>Marks</th><th>Due Date</th><th>Late?</th><th>Actions</th></tr>
        <asp:Repeater ID="rptA" runat="server" OnItemCommand="rptA_ItemCommand">
            <ItemTemplate><tr>
                <td><%#Eval("Title")%></td>
                <td><%#Eval("CourseName")%></td>
                <td><span class="badge badge-blue"><%#Eval("AssignmentType")%></span></td>
                <td><%#Eval("TotalMarks")%></td>
                <td style="font-size:12px"><%#((DateTime)Eval("DueDate")).ToString("MMM dd, yyyy HH:mm")%></td>
                <td><%#((bool)Eval("AllowLateSubmission")?"<span class='badge badge-green'>Yes</span>":"<span class='badge badge-gray'>No</span>")%></td>
                <td>
                    <asp:LinkButton CommandName="Edit" CommandArgument='<%#Eval("AssignmentID")%>' CssClass="btn btn-secondary btn-sm" runat="server">Edit</asp:LinkButton>
                    <asp:LinkButton CommandName="Delete" CommandArgument='<%#Eval("AssignmentID")%>' CssClass="btn btn-danger btn-sm" runat="server" OnClientClick="return confirm('Delete?')">Delete</asp:LinkButton>
                </td>
            </tr></ItemTemplate>
        </asp:Repeater>
    </table>
</div>
<div class="modal-overlay" id="addModal"><div class="modal">
    <div class="modal-title">Add Assignment</div>
    <div class="form-grid">
        <div class="form-group full"><label>Title</label><asp:TextBox ID="txtTitle" runat="server"/></div>
        <div class="form-group"><label>Offering</label><asp:DropDownList ID="ddlOff" runat="server"/></div>
        <div class="form-group"><label>Type</label>
            <asp:DropDownList ID="ddlType" runat="server"><asp:ListItem>Homework</asp:ListItem><asp:ListItem>Quiz</asp:ListItem><asp:ListItem>Exam</asp:ListItem><asp:ListItem>Project</asp:ListItem><asp:ListItem>Lab</asp:ListItem></asp:DropDownList></div>
        <div class="form-group"><label>Total Marks</label><asp:TextBox ID="txtMarks" runat="server" TextMode="Number"/></div>
        <div class="form-group"><label>Due Date</label><asp:TextBox ID="txtDue" runat="server" TextMode="DateTimeLocal"/></div>
        <div class="form-group"><label>Allow Late Submission</label>
            <asp:DropDownList ID="ddlLate" runat="server"><asp:ListItem Value="0">No</asp:ListItem><asp:ListItem Value="1">Yes</asp:ListItem></asp:DropDownList></div>
        <div class="form-group full"><label>Description</label><asp:TextBox ID="txtDesc" runat="server" TextMode="MultiLine"/></div>
    </div>
    <div class="modal-footer">
        <button class="btn btn-secondary" onclick="hideModal('addModal');return false;">Cancel</button>
        <asp:Button runat="server" Text="Add" CssClass="btn btn-primary" OnClick="btnAdd_Click"/>
    </div>
</div></div>
<div class="modal-overlay" id="editModal"><div class="modal">
    <div class="modal-title">Edit Assignment</div>
    <asp:HiddenField ID="hfID" runat="server"/>
    <div class="form-grid">
        <div class="form-group full"><label>Title</label><asp:TextBox ID="txtETitle" runat="server"/></div>
        <div class="form-group"><label>Type</label>
            <asp:DropDownList ID="ddlEType" runat="server"><asp:ListItem>Homework</asp:ListItem><asp:ListItem>Quiz</asp:ListItem><asp:ListItem>Exam</asp:ListItem><asp:ListItem>Project</asp:ListItem><asp:ListItem>Lab</asp:ListItem></asp:DropDownList></div>
        <div class="form-group"><label>Total Marks</label><asp:TextBox ID="txtEMarks" runat="server"/></div>
        <div class="form-group"><label>Due Date</label><asp:TextBox ID="txtEDue" runat="server" TextMode="DateTimeLocal"/></div>
        <div class="form-group"><label>Allow Late</label>
            <asp:DropDownList ID="ddlELate" runat="server"><asp:ListItem Value="0">No</asp:ListItem><asp:ListItem Value="1">Yes</asp:ListItem></asp:DropDownList></div>
        <div class="form-group full"><label>Description</label><asp:TextBox ID="txtEDesc" runat="server" TextMode="MultiLine"/></div>
    </div>
    <div class="modal-footer">
        <button class="btn btn-secondary" onclick="hideModal('editModal');return false;">Cancel</button>
        <asp:Button runat="server" Text="Save" CssClass="btn btn-primary" OnClick="btnUpdate_Click"/>
    </div>
</div></div>
<script>function showModal(id){document.getElementById(id).classList.add('show');}function hideModal(id){document.getElementById(id).classList.remove('show');}</script>
<asp:Literal ID="litEditScript" runat="server"/>
</asp:Content>
