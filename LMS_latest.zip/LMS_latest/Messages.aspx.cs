using System;
using System.Web.UI.WebControls;

public partial class Messages : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack) { LoadData(); BindUsers(ddlSender); BindUsers(ddlReceiver); }
    }

    void LoadData()
    {
        rptMsg.DataSource = DB.Query(
            "SELECT m.*,s.FirstName+' '+s.LastName AS SenderName,r.FirstName+' '+r.LastName AS ReceiverName " +
            "FROM Messages m JOIN Users s ON m.SenderID=s.UserID " +
            "JOIN Users r ON m.ReceiverID=r.UserID ORDER BY m.SentAt DESC");
        rptMsg.DataBind();
    }

    void BindUsers(DropDownList ddl)
    {
        ddl.DataSource = DB.Query("SELECT UserID,FirstName+' '+LastName+' ('+UserType+')' AS Name FROM Users");
        ddl.DataTextField = "Name";
        ddl.DataValueField = "UserID";
        ddl.DataBind();
    }

    protected void btnSend_Click(object sender, EventArgs e)
    {
        if (ddlSender.SelectedValue == ddlReceiver.SelectedValue)
        {
            litMsg.Text = "<div class='alert alert-danger'>Sender and receiver must be different users.</div>";
            return;
        }
        try
        {
            DB.Execute("INSERT INTO Messages(SenderID,ReceiverID,Subject,MessageBody) VALUES(@s,@r,@sub,@b)",
                DB.P("@s", ddlSender.SelectedValue), DB.P("@r", ddlReceiver.SelectedValue),
                DB.P("@sub", txtSubject.Text), DB.P("@b", txtBody.Text));
            litMsg.Text = "<div class='alert alert-success'>Message sent.</div>";
        }
        catch (Exception ex)
        {
            litMsg.Text = "<div class='alert alert-danger'>Error: " + ex.Message + "</div>";
        }
        LoadData();
    }

    protected void rptMsg_ItemCommand(object s, RepeaterCommandEventArgs e)
    {
        int id = int.Parse(e.CommandArgument.ToString());
        if (e.CommandName == "Delete")
        {
            DB.Execute("DELETE FROM Messages WHERE MessageID=@id", DB.P("@id", id));
            litMsg.Text = "<div class='alert alert-success'>Deleted.</div>";
            LoadData();
        }
        else if (e.CommandName == "View")
        {
            var r = DB.Query(
                "SELECT m.*,s.FirstName+' '+s.LastName AS SN,rc.FirstName+' '+rc.LastName AS RN " +
                "FROM Messages m JOIN Users s ON m.SenderID=s.UserID " +
                "JOIN Users rc ON m.ReceiverID=rc.UserID WHERE m.MessageID=@id",
                DB.P("@id", id)).Rows[0];
            hfID.Value = id.ToString();
            litFromTo.Text = "<strong>" + r["SN"].ToString() + "</strong> &rarr; <strong>" + r["RN"].ToString() + "</strong>";
            litSubject.Text = "<strong>" + r["Subject"].ToString() + "</strong>";
            litBody.Text = System.Web.HttpUtility.HtmlEncode(r["MessageBody"].ToString()).Replace("\n", "<br/>");
            DB.Execute("UPDATE Messages SET IsRead=1,ReadAt=GETDATE() WHERE MessageID=@id", DB.P("@id", id));
            litViewScript.Text = "<script>showModal('viewModal');<" + "/script>";
            LoadData();
        }
    }
}
