using System;
using System.Web.UI.WebControls;

public partial class Materials : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack) { LoadData(); BindOfferings(); BindUploaders(); }
    }

    void LoadData()
    {
        rptMat.DataSource = DB.Query(
            "SELECT m.*,c.CourseName,u.FirstName+' '+u.LastName AS UploaderName " +
            "FROM CourseMaterials m JOIN CourseOfferings co ON m.OfferingID=co.OfferingID " +
            "JOIN Courses c ON co.CourseID=c.CourseID " +
            "JOIN Users u ON m.UploadedBy=u.UserID ORDER BY m.UploadDate DESC");
        rptMat.DataBind();
    }

    void BindOfferings()
    {
        ddlOff.DataSource = DB.Query(
            "SELECT co.OfferingID,c.CourseCode+' '+co.Semester+' '+CAST(co.Year AS VARCHAR) AS Label " +
            "FROM CourseOfferings co JOIN Courses c ON co.CourseID=c.CourseID");
        ddlOff.DataTextField = "Label";
        ddlOff.DataValueField = "OfferingID";
        ddlOff.DataBind();
    }

    void BindUploaders()
    {
        ddlUploader.DataSource = DB.Query("SELECT UserID,FirstName+' '+LastName AS Name FROM Users WHERE UserType IN('Teacher','Admin')");
        ddlUploader.DataTextField = "Name";
        ddlUploader.DataValueField = "UserID";
        ddlUploader.DataBind();
    }

    protected void btnAdd_Click(object sender, EventArgs e)
    {
        try
        {
            object fileSize = string.IsNullOrEmpty(txtSize.Text) ? (object)DBNull.Value : (object)txtSize.Text;
            DB.Execute("INSERT INTO CourseMaterials(OfferingID,UploadedBy,Title,Description,MaterialType,FilePath,FileSize) VALUES(@o,@u,@t,@d,@tp,@fp,@fs)",
                DB.P("@o", ddlOff.SelectedValue), DB.P("@u", ddlUploader.SelectedValue),
                DB.P("@t", txtTitle.Text), DB.P("@d", txtDesc.Text),
                DB.P("@tp", ddlType.SelectedValue), DB.P("@fp", txtPath.Text),
                DB.P("@fs", fileSize));
            litMsg.Text = "<div class='alert alert-success'>Material added.</div>";
        }
        catch (Exception ex)
        {
            litMsg.Text = "<div class='alert alert-danger'>Error: " + ex.Message + "</div>";
        }
        LoadData();
    }

    protected void rptMat_ItemCommand(object s, RepeaterCommandEventArgs e)
    {
        int id = int.Parse(e.CommandArgument.ToString());
        if (e.CommandName == "Delete")
        {
            DB.Execute("DELETE FROM CourseMaterials WHERE MaterialID=@id", DB.P("@id", id));
            litMsg.Text = "<div class='alert alert-success'>Deleted.</div>";
            LoadData();
        }
        else if (e.CommandName == "Edit")
        {
            var r = DB.Query("SELECT * FROM CourseMaterials WHERE MaterialID=@id", DB.P("@id", id)).Rows[0];
            hfID.Value = id.ToString();
            txtETitle.Text = r["Title"].ToString();
            txtEDesc.Text = r["Description"].ToString();
            ddlEType.SelectedValue = r["MaterialType"].ToString();
            ddlEActive.SelectedValue = r["IsActive"].ToString();
            litEditScript.Text = "<script>showModal('editModal');<" + "/script>";
        }
    }

    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        try
        {
            DB.Execute("UPDATE CourseMaterials SET Title=@t,Description=@d,MaterialType=@tp,IsActive=@a WHERE MaterialID=@id",
                DB.P("@t", txtETitle.Text), DB.P("@d", txtEDesc.Text),
                DB.P("@tp", ddlEType.SelectedValue), DB.P("@a", ddlEActive.SelectedValue),
                DB.P("@id", hfID.Value));
            litMsg.Text = "<div class='alert alert-success'>Updated.</div>";
        }
        catch (Exception ex)
        {
            litMsg.Text = "<div class='alert alert-danger'>Error: " + ex.Message + "</div>";
        }
        LoadData();
    }
}
