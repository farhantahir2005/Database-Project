<%@ Page Title="Attendance" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true" CodeFile="Attendance.aspx.cs" Inherits="Attendance" %>
<asp:Content ContentPlaceHolderID="MainContent" runat="server">
<div class="page-title">Attendance</div>
<div class="page-sub">Track student attendance per class session</div>
<asp:Literal ID="litMsg" runat="server"/>
<div class="card">
    <div class="action-row">
        <span class="card-title" style="margin:0">Attendance Records</span>
        <button class="btn btn-primary btn-sm" onclick="showModal('addModal');return false;">+ Mark Attendance</button>
    </div>
    <table>
        <tr><th>Student</th><th>Course</th><th>Date</th><th>Status</th><th>Remarks</th><th>Marked By</th><th>Actions</th></tr>
        <asp:Repeater ID="rptAtt" runat="server" OnItemCommand="rptAtt_ItemCommand">
            <ItemTemplate><tr>
                <td><%#Eval("StudentName")%></td>
                <td><%#Eval("CourseName")%></td>
                <td><%#((DateTime)Eval("AttendanceDate")).ToString("MMM dd, yyyy")%></td>
                <td><span class='badge <%#(string)Eval("Status")=="Present"?"badge-green":(string)Eval("Status")=="Absent"?"badge-red":(string)Eval("Status")=="Late"?"badge-blue":"badge-gray"%>'><%#Eval("Status")%></span></td>
                <td style="font-size:12px;color:var(--muted)"><%#Eval("Remarks")%></td>
                <td><%#Eval("MarkedByName")%></td>
                <td>
                    <asp:LinkButton CommandName="Edit" CommandArgument='<%#Eval("AttendanceID")%>' CssClass="btn btn-secondary btn-sm" runat="server">Edit</asp:LinkButton>
                    <asp:LinkButton CommandName="Delete" CommandArgument='<%#Eval("AttendanceID")%>' CssClass="btn btn-danger btn-sm" runat="server" OnClientClick="return confirm('Delete?')">Delete</asp:LinkButton>
                </td>
            </tr></ItemTemplate>
        </asp:Repeater>
    </table>
</div>
<div class="modal-overlay" id="addModal"><div class="modal">
    <div class="modal-title">Mark Attendance</div>
    <div class="form-grid">
        <div class="form-group"><label>Student</label><asp:DropDownList ID="ddlStudent" runat="server"/></div>
        <div class="form-group"><label>Offering</label><asp:DropDownList ID="ddlOff" runat="server"/></div>
        <div class="form-group"><label>Date</label><asp:TextBox ID="txtDate" runat="server" TextMode="Date"/></div>
        <div class="form-group"><label>Status</label>
            <asp:DropDownList ID="ddlStatus" runat="server"><asp:ListItem>Present</asp:ListItem><asp:ListItem>Absent</asp:ListItem><asp:ListItem>Late</asp:ListItem><asp:ListItem>Excused</asp:ListItem></asp:DropDownList></div>
        <div class="form-group"><label>Marked By</label><asp:DropDownList ID="ddlMarker" runat="server"/></div>
        <div class="form-group full"><label>Remarks</label><asp:TextBox ID="txtRemarks" runat="server"/></div>
    </div>
    <div class="modal-footer">
        <button class="btn btn-secondary" onclick="hideModal('addModal');return false;">Cancel</button>
        <asp:Button runat="server" Text="Save" CssClass="btn btn-primary" OnClick="btnAdd_Click"/>
    </div>
</div></div>
<div class="modal-overlay" id="editModal"><div class="modal">
    <div class="modal-title">Edit Attendance</div>
    <asp:HiddenField ID="hfID" runat="server"/>
    <div class="form-grid">
        <div class="form-group"><label>Status</label>
            <asp:DropDownList ID="ddlEStatus" runat="server"><asp:ListItem>Present</asp:ListItem><asp:ListItem>Absent</asp:ListItem><asp:ListItem>Late</asp:ListItem><asp:ListItem>Excused</asp:ListItem></asp:DropDownList></div>
        <div class="form-group full"><label>Remarks</label><asp:TextBox ID="txtERemarks" runat="server"/></div>
    </div>
    <div class="modal-footer">
        <button class="btn btn-secondary" onclick="hideModal('editModal');return false;">Cancel</button>
        <asp:Button runat="server" Text="Save" CssClass="btn btn-primary" OnClick="btnUpdate_Click"/>
    </div>
</div></div>
<script>function showModal(id){document.getElementById(id).classList.add('show');}function hideModal(id){document.getElementById(id).classList.remove('show');}</script>
<asp:Literal ID="litEditScript" runat="server"/>
</asp:Content>
