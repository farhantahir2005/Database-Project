using System;
using System.Web.UI.WebControls;

public partial class Courses : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack) { LoadData(); BindDepts(ddlDept); BindDepts(ddlEDept); }
    }

    void LoadData()
    {
        rptCourses.DataSource = DB.Query(
            "SELECT c.*,d.DepartmentName AS DeptName FROM Courses c " +
            "JOIN Departments d ON c.DepartmentID=d.DepartmentID ORDER BY c.CourseID DESC");
        rptCourses.DataBind();
    }

    void BindDepts(DropDownList ddl)
    {
        ddl.DataSource = DB.Query("SELECT DepartmentID,DepartmentName FROM Departments");
        ddl.DataTextField = "DepartmentName";
        ddl.DataValueField = "DepartmentID";
        ddl.DataBind();
    }

    protected void btnAdd_Click(object sender, EventArgs e)
    {
        try
        {
            DB.Execute("INSERT INTO Courses(CourseCode,CourseName,DepartmentID,Credits,Description,Prerequisites) VALUES(@c,@n,@d,@cr,@ds,@p)",
                DB.P("@c", txtCode.Text), DB.P("@n", txtName.Text),
                DB.P("@d", ddlDept.SelectedValue), DB.P("@cr", txtCredits.Text),
                DB.P("@ds", txtDesc.Text), DB.P("@p", txtPre.Text));
            litMsg.Text = "<div class='alert alert-success'>Course added.</div>";
        }
        catch (Exception ex)
        {
            litMsg.Text = "<div class='alert alert-danger'>Error: " + ex.Message + "</div>";
        }
        LoadData();
    }

    protected void rptCourses_ItemCommand(object s, RepeaterCommandEventArgs e)
    {
        int id = int.Parse(e.CommandArgument.ToString());
        if (e.CommandName == "Delete")
        {
            DB.Execute("DELETE FROM Courses WHERE CourseID=@id", DB.P("@id", id));
            litMsg.Text = "<div class='alert alert-success'>Deleted.</div>";
            LoadData();
        }
        else if (e.CommandName == "Edit")
        {
            var r = DB.Query("SELECT * FROM Courses WHERE CourseID=@id", DB.P("@id", id)).Rows[0];
            hfID.Value = id.ToString();
            txtECode.Text = r["CourseCode"].ToString();
            txtEName.Text = r["CourseName"].ToString();
            txtECredits.Text = r["Credits"].ToString();
            txtEDesc.Text = r["Description"].ToString();
            txtEPre.Text = r["Prerequisites"].ToString();
            BindDepts(ddlEDept);
            ddlEDept.SelectedValue = r["DepartmentID"].ToString();
            ddlEActive.SelectedValue = r["IsActive"].ToString();
            litEditScript.Text = "<script>showModal('editModal');<" + "/script>";
        }
    }

    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        try
        {
            DB.Execute("UPDATE Courses SET CourseCode=@c,CourseName=@n,DepartmentID=@d,Credits=@cr,Description=@ds,Prerequisites=@p,IsActive=@a WHERE CourseID=@id",
                DB.P("@c", txtECode.Text), DB.P("@n", txtEName.Text),
                DB.P("@d", ddlEDept.SelectedValue), DB.P("@cr", txtECredits.Text),
                DB.P("@ds", txtEDesc.Text), DB.P("@p", txtEPre.Text),
                DB.P("@a", ddlEActive.SelectedValue), DB.P("@id", hfID.Value));
            litMsg.Text = "<div class='alert alert-success'>Updated.</div>";
        }
        catch (Exception ex)
        {
            litMsg.Text = "<div class='alert alert-danger'>Error: " + ex.Message + "</div>";
        }
        LoadData();
    }
}
