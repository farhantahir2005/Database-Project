<%@ Page Title="Courses" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true" CodeFile="Courses.aspx.cs" Inherits="Courses" %>
<asp:Content ContentPlaceHolderID="MainContent" runat="server">
<div class="page-title">Courses</div>
<div class="page-sub">Manage course catalog</div>
<asp:Literal ID="litMsg" runat="server"/>
<div class="card">
    <div class="action-row">
        <span class="card-title" style="margin:0">All Courses</span>
        <button class="btn btn-primary btn-sm" onclick="showModal('addModal');return false;">+ Add Course</button>
    </div>
    <table>
        <tr><th>Code</th><th>Name</th><th>Department</th><th>Credits</th><th>Active</th><th>Actions</th></tr>
        <asp:Repeater ID="rptCourses" runat="server" OnItemCommand="rptCourses_ItemCommand">
            <ItemTemplate>
                <tr>
                    <td><span class="badge badge-blue"><%#Eval("CourseCode")%></span></td>
                    <td><%#Eval("CourseName")%></td>
                    <td><%#Eval("DeptName")%></td>
                    <td><%#Eval("Credits")%></td>
                    <td><%#((bool)Eval("IsActive")?"<span class='badge badge-green'>Yes</span>":"<span class='badge badge-gray'>No</span>")%></td>
                    <td>
                        <asp:LinkButton CommandName="Edit" CommandArgument='<%#Eval("CourseID")%>' CssClass="btn btn-secondary btn-sm" runat="server">Edit</asp:LinkButton>
                        <asp:LinkButton CommandName="Delete" CommandArgument='<%#Eval("CourseID")%>' CssClass="btn btn-danger btn-sm" runat="server" OnClientClick="return confirm('Delete?')">Delete</asp:LinkButton>
                    </td>
                </tr>
            </ItemTemplate>
        </asp:Repeater>
    </table>
</div>
<div class="modal-overlay" id="addModal"><div class="modal">
    <div class="modal-title">Add Course</div>
    <div class="form-grid">
        <div class="form-group"><label>Course Code</label><asp:TextBox ID="txtCode" runat="server"/></div>
        <div class="form-group"><label>Course Name</label><asp:TextBox ID="txtName" runat="server"/></div>
        <div class="form-group"><label>Department</label><asp:DropDownList ID="ddlDept" runat="server"/></div>
        <div class="form-group"><label>Credits</label><asp:TextBox ID="txtCredits" runat="server" TextMode="Number"/></div>
        <div class="form-group full"><label>Description</label><asp:TextBox ID="txtDesc" runat="server" TextMode="MultiLine"/></div>
        <div class="form-group full"><label>Prerequisites</label><asp:TextBox ID="txtPre" runat="server"/></div>
    </div>
    <div class="modal-footer">
        <button class="btn btn-secondary" onclick="hideModal('addModal');return false;">Cancel</button>
        <asp:Button runat="server" Text="Add" CssClass="btn btn-primary" OnClick="btnAdd_Click"/>
    </div>
</div></div>
<div class="modal-overlay" id="editModal"><div class="modal">
    <div class="modal-title">Edit Course</div>
    <asp:HiddenField ID="hfID" runat="server"/>
    <div class="form-grid">
        <div class="form-group"><label>Course Code</label><asp:TextBox ID="txtECode" runat="server"/></div>
        <div class="form-group"><label>Course Name</label><asp:TextBox ID="txtEName" runat="server"/></div>
        <div class="form-group"><label>Department</label><asp:DropDownList ID="ddlEDept" runat="server"/></div>
        <div class="form-group"><label>Credits</label><asp:TextBox ID="txtECredits" runat="server" TextMode="Number"/></div>
        <div class="form-group full"><label>Description</label><asp:TextBox ID="txtEDesc" runat="server" TextMode="MultiLine"/></div>
        <div class="form-group full"><label>Prerequisites</label><asp:TextBox ID="txtEPre" runat="server"/></div>
        <div class="form-group"><label>Active</label><asp:DropDownList ID="ddlEActive" runat="server"><asp:ListItem Value="1">Yes</asp:ListItem><asp:ListItem Value="0">No</asp:ListItem></asp:DropDownList></div>
    </div>
    <div class="modal-footer">
        <button class="btn btn-secondary" onclick="hideModal('editModal');return false;">Cancel</button>
        <asp:Button runat="server" Text="Save" CssClass="btn btn-primary" OnClick="btnUpdate_Click"/>
    </div>
</div></div>
<script>function showModal(id){document.getElementById(id).classList.add('show');}function hideModal(id){document.getElementById(id).classList.remove('show');}</script>
<asp:Literal ID="litEditScript" runat="server"/>
</asp:Content>
