using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public static class DB
{
    public static string ConnStr
    {
        get { return ConfigurationManager.ConnectionStrings["LMSConn"].ConnectionString; }
    }

    // ── Ad-hoc query (SELECT) ─────────────────────────────────────────
    public static DataTable Query(string sql, params SqlParameter[] ps)
    {
        using (var con = new SqlConnection(ConnStr))
        using (var cmd = new SqlCommand(sql, con))
        {
            if (ps != null) cmd.Parameters.AddRange(ps);
            con.Open();
            var dt = new DataTable();
            new SqlDataAdapter(cmd).Fill(dt);
            return dt;
        }
    }

    // ── Ad-hoc non-query (INSERT / UPDATE / DELETE) ───────────────────
    public static int Execute(string sql, params SqlParameter[] ps)
    {
        using (var con = new SqlConnection(ConnStr))
        using (var cmd = new SqlCommand(sql, con))
        {
            if (ps != null) cmd.Parameters.AddRange(ps);
            con.Open();
            return cmd.ExecuteNonQuery();
        }
    }

    // ── Ad-hoc scalar ─────────────────────────────────────────────────
    public static object Scalar(string sql, params SqlParameter[] ps)
    {
        using (var con = new SqlConnection(ConnStr))
        using (var cmd = new SqlCommand(sql, con))
        {
            if (ps != null) cmd.Parameters.AddRange(ps);
            con.Open();
            return cmd.ExecuteScalar();
        }
    }

    // ── Stored-procedure query (returns DataTable) ────────────────────
    public static DataTable ExecProc(string procName, params SqlParameter[] ps)
    {
        using (var con = new SqlConnection(ConnStr))
        using (var cmd = new SqlCommand(procName, con))
        {
            cmd.CommandType = CommandType.StoredProcedure;
            if (ps != null) cmd.Parameters.AddRange(ps);
            con.Open();
            var dt = new DataTable();
            new SqlDataAdapter(cmd).Fill(dt);
            return dt;
        }
    }

    // ── Stored-procedure non-query ────────────────────────────────────
    public static int ExecProcNQ(string procName, params SqlParameter[] ps)
    {
        using (var con = new SqlConnection(ConnStr))
        using (var cmd = new SqlCommand(procName, con))
        {
            cmd.CommandType = CommandType.StoredProcedure;
            if (ps != null) cmd.Parameters.AddRange(ps);
            con.Open();
            return cmd.ExecuteNonQuery();
        }
    }

    // ── Stored-procedure with OUTPUT parameter ────────────────────────
    public static int ExecProcOutput(string procName, string outputParamName, params SqlParameter[] ps)
    {
        using (var con = new SqlConnection(ConnStr))
        using (var cmd = new SqlCommand(procName, con))
        {
            cmd.CommandType = CommandType.StoredProcedure;
            if (ps != null) cmd.Parameters.AddRange(ps);
            var outParam = new SqlParameter(outputParamName, SqlDbType.Int)
            {
                Direction = ParameterDirection.Output
            };
            cmd.Parameters.Add(outParam);
            con.Open();
            cmd.ExecuteNonQuery();
            return outParam.Value != DBNull.Value ? (int)outParam.Value : -1;
        }
    }

    // ── Parameter helper ──────────────────────────────────────────────
    public static SqlParameter P(string name, object val)
    {
        return new SqlParameter(name, val ?? DBNull.Value);
    }
}
