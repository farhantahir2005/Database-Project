using System;
using System.IO;
public partial class Site : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e) { }
    public bool IsActivePage(string page)
    {
        return Path.GetFileName(Request.FilePath).Equals(page, StringComparison.OrdinalIgnoreCase);
    }
}
