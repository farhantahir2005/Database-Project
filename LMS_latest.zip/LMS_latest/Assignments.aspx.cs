using System;
using System.Web.UI.WebControls;

public partial class Assignments : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack) { LoadData(); BindOfferings(ddlOff); }
    }

    void LoadData()
    {
        rptA.DataSource = DB.Query(
            "SELECT a.*,c.CourseName FROM Assignments a " +
            "JOIN CourseOfferings co ON a.OfferingID=co.OfferingID " +
            "JOIN Courses c ON co.CourseID=c.CourseID ORDER BY a.DueDate DESC");
        rptA.DataBind();
    }

    void BindOfferings(DropDownList ddl)
    {
        ddl.DataSource = DB.Query(
            "SELECT co.OfferingID,c.CourseCode+' '+co.Semester+' '+CAST(co.Year AS VARCHAR) AS Label " +
            "FROM CourseOfferings co JOIN Courses c ON co.CourseID=c.CourseID");
        ddl.DataTextField = "Label";
        ddl.DataValueField = "OfferingID";
        ddl.DataBind();
    }

    protected void btnAdd_Click(object sender, EventArgs e)
    {
        try
        {
            DB.Execute("INSERT INTO Assignments(OfferingID,Title,Description,AssignmentType,TotalMarks,DueDate,AllowLateSubmission) VALUES(@o,@t,@d,@tp,@m,@du,@l)",
                DB.P("@o", ddlOff.SelectedValue), DB.P("@t", txtTitle.Text),
                DB.P("@d", txtDesc.Text), DB.P("@tp", ddlType.SelectedValue),
                DB.P("@m", txtMarks.Text), DB.P("@du", txtDue.Text),
                DB.P("@l", ddlLate.SelectedValue));
            litMsg.Text = "<div class='alert alert-success'>Assignment added.</div>";
        }
        catch (Exception ex)
        {
            litMsg.Text = "<div class='alert alert-danger'>Error: " + ex.Message + "</div>";
        }
        LoadData();
    }

    protected void rptA_ItemCommand(object s, RepeaterCommandEventArgs e)
    {
        int id = int.Parse(e.CommandArgument.ToString());
        if (e.CommandName == "Delete")
        {
            DB.Execute("DELETE FROM Assignments WHERE AssignmentID=@id", DB.P("@id", id));
            litMsg.Text = "<div class='alert alert-success'>Deleted.</div>";
            LoadData();
        }
        else if (e.CommandName == "Edit")
        {
            var r = DB.Query("SELECT * FROM Assignments WHERE AssignmentID=@id", DB.P("@id", id)).Rows[0];
            hfID.Value = id.ToString();
            txtETitle.Text = r["Title"].ToString();
            txtEMarks.Text = r["TotalMarks"].ToString();
            txtEDesc.Text = r["Description"].ToString();
            ddlEType.SelectedValue = r["AssignmentType"].ToString();
            ddlELate.SelectedValue = r["AllowLateSubmission"].ToString();
            if (r["DueDate"] != DBNull.Value)
                txtEDue.Text = ((DateTime)r["DueDate"]).ToString("yyyy-MM-ddTHH:mm");
            litEditScript.Text = "<script>showModal('editModal');<" + "/script>";
        }
    }

    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        try
        {
            DB.Execute("UPDATE Assignments SET Title=@t,Description=@d,AssignmentType=@tp,TotalMarks=@m,DueDate=@du,AllowLateSubmission=@l WHERE AssignmentID=@id",
                DB.P("@t", txtETitle.Text), DB.P("@d", txtEDesc.Text),
                DB.P("@tp", ddlEType.SelectedValue), DB.P("@m", txtEMarks.Text),
                DB.P("@du", txtEDue.Text), DB.P("@l", ddlELate.SelectedValue),
                DB.P("@id", hfID.Value));
            litMsg.Text = "<div class='alert alert-success'>Updated.</div>";
        }
        catch (Exception ex)
        {
            litMsg.Text = "<div class='alert alert-danger'>Error: " + ex.Message + "</div>";
        }
        LoadData();
    }
}
