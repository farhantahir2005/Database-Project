using System;
using System.Data;
using System.Data.SqlClient;

public partial class Users : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack) LoadUsers();
    }

    void LoadUsers()
    {
        rptUsers.DataSource = DB.Query("SELECT * FROM Users ORDER BY UserID DESC");
        rptUsers.DataBind();
    }

    protected void btnAdd_Click(object sender, EventArgs e)
    {
        try
        {
            object dob = string.IsNullOrEmpty(txtDOB.Text)
                ? (object)DBNull.Value
                : (object)txtDOB.Text;

            DB.Execute(
                "INSERT INTO Users(Email,Password,FirstName,LastName,UserType,Phone,DateOfBirth) " +
                "VALUES(@e,@p,@fn,@ln,@t,@ph,@dob)",
                DB.P("@e", txtEmail.Text),
                DB.P("@p", txtPwd.Text),
                DB.P("@fn", txtFN.Text),
                DB.P("@ln", txtLN.Text),
                DB.P("@t", ddlType.SelectedValue),
                DB.P("@ph", txtPhone.Text),
                DB.P("@dob", dob));

            litMsg.Text = "<div class='alert alert-success'>User added successfully.</div>";
            txtFN.Text = txtLN.Text = txtEmail.Text = txtPwd.Text = txtPhone.Text = txtDOB.Text = "";
        }
        catch (Exception ex)
        {
            litMsg.Text = "<div class='alert alert-danger'>Error: " + ex.Message + "</div>";
        }
        LoadUsers();
    }

    protected void rptUsers_ItemCommand(object source, System.Web.UI.WebControls.RepeaterCommandEventArgs e)
    {
        int id = int.Parse(e.CommandArgument.ToString());

        if (e.CommandName == "Delete")
        {
            DB.Execute("DELETE FROM Users WHERE UserID=@id", DB.P("@id", id));
            litMsg.Text = "<div class='alert alert-success'>User deleted.</div>";
            LoadUsers();
        }
        else if (e.CommandName == "Edit")
        {
            var dt = DB.Query("SELECT * FROM Users WHERE UserID=@id", DB.P("@id", id));
            if (dt.Rows.Count > 0)
            {
                var r = dt.Rows[0];
                hfEditID.Value = id.ToString();
                txtEFN.Text = r["FirstName"].ToString();
                txtELN.Text = r["LastName"].ToString();
                txtEEmail.Text = r["Email"].ToString();
                txtEPhone.Text = r["Phone"].ToString();
                ddlEType.SelectedValue = r["UserType"].ToString();
                ddlEActive.SelectedValue = r["IsActive"].ToString();
                litEditScript.Text = "<script>showModal('editModal');<" + "/script>";
            }
        }
    }

    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        try
        {
            DB.Execute(
                "UPDATE Users SET FirstName=@fn,LastName=@ln,Email=@em,UserType=@t,Phone=@ph,IsActive=@a " +
                "WHERE UserID=@id",
                DB.P("@fn", txtEFN.Text),
                DB.P("@ln", txtELN.Text),
                DB.P("@em", txtEEmail.Text),
                DB.P("@t", ddlEType.SelectedValue),
                DB.P("@ph", txtEPhone.Text),
                DB.P("@a", ddlEActive.SelectedValue),
                DB.P("@id", hfEditID.Value));

            litMsg.Text = "<div class='alert alert-success'>User updated.</div>";
        }
        catch (Exception ex)
        {
            litMsg.Text = "<div class='alert alert-danger'>Error: " + ex.Message + "</div>";
        }
        LoadUsers();
    }
}